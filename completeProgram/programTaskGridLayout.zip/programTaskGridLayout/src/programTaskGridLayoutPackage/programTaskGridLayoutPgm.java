package programTaskGridLayoutPackage;

//
// Name: GridLayout
// Version: 0.1
// Target: Mr Di Tomasso
// Author: Aayan Sheraz
// Purpose: It is a car website program but in a GridLayout unlike the FlowLayout allowing for more customization to place the Buttons and Texts. It has 6 Buttons that allows you to pick from 3 different tesla cars, a autopilot option, license plate number option and calculates the full price with HST anf Frieght and displays it.
//

//Import statements
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class programTaskGridLayoutPgm {
    //Declaring Varibles
    final static boolean shouldFill = true;
    final static boolean shouldWeightX = true;
    final static boolean RIGHT_TO_LEFT = false;
    public static JLabel Price;
    public static double TotalCost = 0;

    //Making a Container
    public static void addComponentsToPane(Container pane) {
        if (RIGHT_TO_LEFT) {
            pane.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        }

        //Setting Default Button values
        JButton button;
        pane.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        if (shouldFill) {
            //natural height, maximum width
            c.fill = GridBagConstraints.HORIZONTAL;
        }

        //Jlabel for the Car company
        JLabel text = new JLabel("Tesla Car", SwingConstants.CENTER);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 0;
        pane.add(text, c);

        //CyberTruck Button
        JButton cyberTruckButton = new JButton("CyberTruck");
        if (shouldWeightX) {
            c.weightx = 0.5;
        }
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;
        c.gridy = 1;
        pane.add(cyberTruckButton, c);

        //Model Y Button
        JButton modelYButton = new JButton("Model Y");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 1;
        pane.add(modelYButton, c);

        //Model X Button
        JButton modelXButton = new JButton("Model X");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 1;
        pane.add(modelXButton, c);

        //AutoPilot Button
        JButton autoPilotButton = new JButton("Auto Pilot");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.ipady = 40;      //make this component tall
        c.weightx = 0.0;
        c.gridwidth = 3;
        c.gridx = 0;
        c.gridy = 2;
        pane.add(autoPilotButton, c);

        //Price JLabel
        Price = new JLabel("Total Price is " + TotalCost);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.1;
        c.gridx = 0;
        c.gridy = 5;
        pane.add(Price, c);

        //Checkout BUtton
        JButton checkoutButton = new JButton("Checkout");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.ipady = 0;       //reset to default
        c.weighty = 1.0;   //request any extra vertical space
        c.anchor = GridBagConstraints.PAGE_END; //bottom of space
        c.insets = new Insets(10,0,0,0);  //top padding
        c.gridx = 2;       //aligned with button 2
        c.gridwidth = 1;   //2 columns wide
        c.gridy = 6;       //third row
        pane.add(checkoutButton, c);

        //Restart Selection Button
        JButton restartButton = new JButton("Restart");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.ipady = 0;       //reset to default
        c.weighty = 1.0;   //request any extra vertical space
        c.anchor = GridBagConstraints.PAGE_END; //bottom of space
        c.insets = new Insets(5,0,0,0);  //top padding
        c.gridx = 1;       //aligned with button 2
        c.gridwidth = 1;   //2 columns wide
        c.gridy = 6;       //third row
        pane.add(restartButton, c);

        //LicensePlate Button
        JRadioButton licensePlateRadioButton = new JRadioButton("Liscence Plate Option");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.ipady = 0;       //reset to default
        c.weighty = 1.0;   //request any extra vertical space
        c.anchor = GridBagConstraints.PAGE_END; //bottom of space
        c.insets = new Insets(5,0,0,0);  //top padding
        c.gridx = 1;       //aligned with button 2
        c.gridwidth = 1;   //2 columns wide
        c.gridy = 3;       //third row
        pane.add(licensePlateRadioButton, c);

        //Area to edit the License Plate
        JTextArea licensePlate = new JTextArea("Enter your liscence Plate number");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.ipady = 0;       //reset to default
        c.weighty = 1.0;   //request any extra vertical space
        c.anchor = GridBagConstraints.PAGE_END; //bottom of space
        c.insets = new Insets(5,0,0,0);  //top padding
        c.gridx = 2;       //aligned with button 2
        c.gridwidth = 1;   //2 columns wide
        c.gridy = 3;       //third row
        pane.add(licensePlate, c);




        //CyberTruck Button Listener
        cyberTruckButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e)
                    {
                        cyberTruckButton.setEnabled(false);
                        TotalCost = TotalCost + 159600;
                        Price.setText("Total Price is " + TotalCost);
                    }
                }
        );
        //Model Y Button Listener
        modelYButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e)
                    {
                        modelYButton.setEnabled(false);
                        TotalCost = TotalCost + 136600;
                        Price.setText("Total Price is " + TotalCost);
                    }
                }
        );
        //Model X Button Listener
        modelXButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e)
                    {
                        modelXButton.setEnabled(false);
                        TotalCost = TotalCost + 142300;
                        Price.setText("Total Price is " + TotalCost);
                    }
                }
        );
        //Autopilot Button Listener
        autoPilotButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e)
                    {
                        autoPilotButton.setEnabled(false);
                        TotalCost = TotalCost + 10000;
                        Price.setText("Total Price is " + TotalCost);
                    }
                }
        );
        //Checkout Button Listener
        checkoutButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e)
                    {
                        TotalCost = (TotalCost * 1.13)*1.025;
                        Price.setText("Total Price is " + TotalCost);
                    }
                }
        );
        //Restart Button Listener
        restartButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e)
                    {
                        cyberTruckButton.setEnabled(true);
                        modelXButton.setEnabled(true);
                        modelYButton.setEnabled(true);
                        autoPilotButton.setEnabled(true);
                        TotalCost = 0;
                        Price.setText("Total Price is " + TotalCost);
                    }
                }
        );
        //License Plate Button Listener
        licensePlateRadioButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e)
                    {
                        licensePlate.setEditable(true);
                        TotalCost = TotalCost + 500;
                        Price.setText("Total Price is " + TotalCost);
                    }
                }
        );
    }

    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private static void createAndShowGUI() {
        //Create and set up the window.
        JFrame frame = new JFrame("GridBagLayoutDemo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Set up the content pane.
        addComponentsToPane(frame.getContentPane());

        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
}