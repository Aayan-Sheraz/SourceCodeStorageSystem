package programTaskMenuPackage;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

//
// Name: Shoes Catalog
// Version: 0.1
// Target: Mr. Di Tomaso
// Author: Aayan Sheraz
// Purpose: This is a Shoes Catalog to select different types of shoes from 3 different companies using JMenu to create. It shoes the Menu and the Submenus with the subsubMenus Options that when selected show which shoes have been selected with the price for the shoes.
//
//
//



public class programTaskMenuPgm {

    public static JRadioButtonMenuItem adidasSamba, adidasWomenShoes, menTrainers, nikeAirForce1, nikeDunk, nikeWomen, crocsRed, crocsBlue, crocsGreen;
    public static JLabel Price;
    public static double TotalCost = 0;


    public static void Shoes() {


        //Creating Frame
        JFrame baseSelectionFrame = new JFrame("Shoes Selection");
        baseSelectionFrame.setSize(1200, 980);


        //Creating Menubar
        JMenuBar menuBar = new JMenuBar();
        menuBar.setBorder(BorderFactory.createMatteBorder(0,0,0,1,Color.BLACK));


        //Jlabel for Shoes Selected
        JLabel shoesSelected = new JLabel("Shoes Selected: ", SwingConstants.CENTER);
        JPanel text = new JPanel();
        text.add(shoesSelected);

        //Price Label
        Price = new JLabel("Price is " + TotalCost);
        text.add(Price);

        //Space Label
        JLabel space = new JLabel("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ");
        text.add(space);

        //creating Menus and SubMenus for shoes
        JMenu shoesCatalog = new JMenu("Shoes Catalog");
        shoesCatalog.setMnemonic('S');
        shoesCatalog.addSeparator();

        //Adidas Submenu
        JMenu adidasSubShoesMenu = new JMenu("Adidas Shoes");
        adidasSubShoesMenu.addSeparator();

        adidasSamba = new JRadioButtonMenuItem("Adidas Samba");
        adidasSubShoesMenu.add(adidasSamba);
        JLabel sambaSelected = new JLabel("Adidas Samba are Selected, ");

        adidasWomenShoes = new JRadioButtonMenuItem("Adidas Women Kaptir Flow, ");
        adidasSubShoesMenu.add(adidasWomenShoes);
        JLabel adidasWomenSelected = new JLabel("Adidas Women Kaptir Flow are Selected, ");

        menTrainers = new JRadioButtonMenuItem("Adidas Men Trainers, ");
        adidasSubShoesMenu.add(menTrainers);
        JLabel menTrainersSelected = new JLabel("Men Trainers are Selected, ");


        //Nike SubMenu
        JMenu nikeSubShoesMenu = new JMenu("Nikes shoes");
        nikeSubShoesMenu.addSeparator();

        nikeAirForce1 = new JRadioButtonMenuItem("Air Force 1");
        nikeSubShoesMenu.add(nikeAirForce1);
        JLabel airForceSelected = new JLabel("Air Force 1s are Selected, ");

        nikeDunk = new JRadioButtonMenuItem("Nike Dunk");
        nikeSubShoesMenu.add(nikeDunk);
        JLabel nikeDunkSelected = new JLabel("Nike Dunks are Selected, ");

        nikeWomen = new JRadioButtonMenuItem("Nike Women");
        nikeSubShoesMenu.add(nikeWomen);
        JLabel nikeWomenSelected = new JLabel("Nike Women Shoes are Selected, ");

        //Crocs SubMenu
        JMenu crocsSubShoesMenu = new JMenu("Crocs shoes");
        crocsSubShoesMenu.addSeparator();

        crocsRed = new JRadioButtonMenuItem("Red");
        crocsSubShoesMenu.add(crocsRed);
        JLabel crocsRedSelected = new JLabel("Crocs Red are Selected, ");

        crocsBlue = new JRadioButtonMenuItem("Blue");
        crocsSubShoesMenu.add(crocsBlue);
        JLabel crocsBlueSelected = new JLabel("Crocs Blue are Selected, ");

        crocsGreen = new JRadioButtonMenuItem("Green");
        crocsSubShoesMenu.add(crocsGreen);
        JLabel crocsGreenSelected = new JLabel("Crocs Green are Selected, ");

        //Creating Menus and SubMenus for Accessories
        JMenu Accessories = new JMenu("Accessories Catalog");
        Accessories.setMnemonic('A');
        Accessories.addSeparator();

        //Watches SubMenu
        JMenu Watches = new JMenu("Watches");
        nikeSubShoesMenu.addSeparator();

        JRadioButtonMenuItem Rolex = new JRadioButtonMenuItem("Rolex");
        Watches.add(Rolex);
        JLabel rolexSelection = new JLabel("Rolex are Selected, ");

        //Adding Accessories's Sub Menu
        Accessories.add(Watches);

        //Adding SubMenus to Menu
        shoesCatalog.add(adidasSubShoesMenu);
        shoesCatalog.add(nikeSubShoesMenu);
        shoesCatalog.add(crocsSubShoesMenu);


        //Making File, Help, About Menu
        JMenu helpMenu = new JMenu("Help");
        helpMenu.setMnemonic('H');

        JMenu aboutSubMenu = new JMenu("About Catalog");
        shoesCatalog.add(aboutSubMenu);

        JMenu fileMenu = new JMenu("File");
        fileMenu.setMnemonic('F');

        //Exit Item
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.setMnemonic('x');
        exitItem.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        System.exit(0);
                    }
                }
        );

        JMenuItem restartItem = new JMenuItem("Restart");
        helpMenu.add(restartItem);
        restartItem.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        airForceSelected.setText("");
                        nikeWomenSelected.setText("");
                        nikeDunkSelected.setText("");
                        adidasWomenSelected.setText("");
                        menTrainersSelected.setText("");
                        sambaSelected.setText("");
                        crocsRedSelected.setText("");
                        crocsBlueSelected.setText("");
                        crocsGreenSelected.setText("");
                        rolexSelection.setText("");
                        Price.setText("The Price: $0");
                        nikeAirForce1.setEnabled(true);
                        nikeDunk.setEnabled(true);
                        nikeWomen.setEnabled(true);
                        adidasSamba.setEnabled(true);
                        adidasWomenShoes.setEnabled(true);
                        menTrainers.setEnabled(true);
                        crocsRed.setEnabled(true);
                        crocsBlue.setEnabled(true);
                        crocsGreen.setEnabled(true);
                        Rolex.setEnabled(true);
                    }
                }
        );


        //Adidas Buttons:
        adidasSamba.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent e )
                    {
                        sambaSelected.setText("Adidas: Samba             ");
                        text.add(sambaSelected);
                        TotalCost = TotalCost + 300;
                        Price.setText("Total Price is " + TotalCost);
                    }
                }
        );

        adidasWomenShoes.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent e )
                    {
                        adidasWomenSelected.setText("Adidas: Women's shoes          ");
                        text.add(adidasWomenSelected);
                        TotalCost = TotalCost + 150;
                        Price.setText("Total Price is " + TotalCost);
                    }
                }
        );

        menTrainers.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent e )
                    {
                        menTrainersSelected.setText("Adidas: Men Trainers         ");
                        text.add(menTrainersSelected);
                        TotalCost = TotalCost + 150;
                        Price.setText("Total Price is " + TotalCost);
                    }
                }
        );

        //Nikes Button:
        nikeAirForce1.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent e )
                    {
                        airForceSelected.setText("Nike: Air Force 1                ");
                        text.add(airForceSelected);
                        TotalCost = TotalCost + 500;
                        Price.setText("Total Price is " + TotalCost);
                    }
                }
        );

        nikeDunk.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent e )
                    {
                        nikeDunkSelected.setText("Nike: Nike Dunks               ");
                        text.add(nikeDunkSelected);
                        TotalCost = TotalCost + 250;
                        Price.setText("Total Price is " + TotalCost);
                    }
                }
        );

        nikeWomen.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent e )
                    {
                        nikeWomenSelected.setText("Nike: Women's Nike             ");
                        text.add(nikeWomenSelected);
                        TotalCost = TotalCost + 250;
                        Price.setText("Total Price is " + TotalCost);
                    }
                }
        );

        //Crocs Button:

        crocsRed.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent e )
                    {
                        crocsRedSelected.setText("Crocs: Red           ");
                        text.add(crocsRedSelected);
                        TotalCost = TotalCost + 100;
                        Price.setText("Total Price is " + TotalCost);
                    }
                }
        );

        crocsBlue.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent e )
                    {
                        crocsBlueSelected.setText("Crocs: Blue          ");
                        text.add(crocsBlueSelected);
                        TotalCost = TotalCost + 100;
                        Price.setText("Total Price is " + TotalCost);
                    }
                }
        );

        crocsGreen.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent e )
                    {
                        crocsGreenSelected.setText("Crocs: Greem          ");
                        text.add(crocsGreenSelected);
                        TotalCost = TotalCost + 100;
                        Price.setText("Total Price is " + TotalCost);
                    }
                }
        );

        Rolex.addActionListener(
                new ActionListener() {
                    public void actionPerformed( ActionEvent e )
                    {
                        Rolex.setText("Watches: Rolex          ");
                        text.add(rolexSelection);
                        TotalCost = TotalCost + 12000;
                        Price.setText("Total Price is " + TotalCost);
                    }
                }
        );


        fileMenu.add(exitItem);
        menuBar.add(fileMenu);    // add File menu

        menuBar.add(helpMenu);
        menuBar.add(shoesCatalog);
        menuBar.add(Accessories);

        baseSelectionFrame.add(text);
        baseSelectionFrame.setJMenuBar(menuBar);
        menuBar.setVisible(true);
        baseSelectionFrame.setVisible(true);


    }

    public static void main(String args[]) {
        Shoes();
    }
}