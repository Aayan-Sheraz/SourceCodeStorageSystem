//***************************************************
//Name: Culminating Project Task
//Version: 0.1
//Target: Mr. Di Tomaso
//Author: Aayan Sheraz
//Purpose: There are 2 buttons that are there to show you that Buttons work on this application and after that there is a product order sections that has uses checkboxes to pick 3 different computers, a Dell XPS 15 laptop, Alienware Aurora R15, Microsoft Surface Pro 9. After that there are the exact same options, but you can only pick 1 of the choices. There are 2 Calculate price buttons, one for the checkboxes and the other for radio button, finally there is something a little extra to reset the selection for the radio Buttons in case you want to switch. There are 2 text fields that display the price of the checkbox and radio button selection with taxs and environment fee accounted for.
//***************************************************

package CulminatingPackage;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;


//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class CulminatingProgramming {

    //Variable
    public static JButton teslaLogoButton, mercedesButton, showPriceButton1, showPriceButton2, resetButton;
    public static JCheckBox dellXpsCheckBox, alienwareCheckBox, microsoftCheckBox;
    public static double totalPrice1, totalPrice2;
    public static JRadioButton DellXpsRadioButton, alienwareRadioButton, microsoftRadioButton;
    public static JTextField buttonChecker, totalPriceTextfield1, totalPriceTextfield2;

    public static void Culminating() {

        //Creating Frame
        JFrame baseFrame = new JFrame("Culminating Programming Task");
        baseFrame.setSize(1200, 980);
        JPanel mainJPanel = new JPanel();
        baseFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        baseFrame.add(mainJPanel);
        baseFrame.setSize(1200, 1000);
        baseFrame.setVisible(true);

        //Creating Button 1 and Logo
        Icon teslaLogoImage = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\CulminatingProject\\Images\\teslaLogo.png");
        Image newteslaLogoImage = ((ImageIcon) teslaLogoImage).getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH);
        teslaLogoImage = new ImageIcon(newteslaLogoImage);
        teslaLogoButton = new JButton(teslaLogoImage);
        JLabel button1Label = new JLabel("Button 1: ");
        mainJPanel.add(button1Label);

        //Push Button Icon
        Icon pushButton = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\CulminatingProject\\Images\\pushButton.png");
        Image newpushButton = ((ImageIcon) pushButton).getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH);
        pushButton = new ImageIcon(newpushButton);

        //Creating Button 2 and Logo
        Icon mercedesLogo = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\CulminatingProject\\Images\\mercedesLogo.png");
        Image newMercedesLogo = ((ImageIcon) mercedesLogo).getImage().getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH);
        mercedesLogo = new ImageIcon(newMercedesLogo);
        mercedesButton = new JButton("This is Button 2", mercedesLogo);
        JLabel button2Label = new JLabel("Button 2: ");
        mercedesButton.setRolloverIcon(pushButton);



        //Creating reset Button
        resetButton = new JButton("Reset Selection Radio Button");
        resetButton.setBounds(1000, 350, 250, 50);

        //Adding TextField
        buttonChecker = new JTextField("This is a Text Field");
        buttonChecker.setEditable(false);

        //Creating CheckList Icons
        Icon dellXPS15 = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\CulminatingProject\\Images\\dellXPS15.png");
        Image newdellXPS15 = ((ImageIcon) dellXPS15).getImage().getScaledInstance(125, 75, java.awt.Image.SCALE_SMOOTH);
        dellXPS15 = new ImageIcon(newdellXPS15);

        Icon Aleinware = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\CulminatingProject\\Images\\Alienware.png");
        Image newAleinware = ((ImageIcon) Aleinware).getImage().getScaledInstance(125, 75, java.awt.Image.SCALE_SMOOTH);
        Aleinware = new ImageIcon(newAleinware);

        Icon microsoft = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\CulminatingProject\\Images\\Mircosoft.png");
        Image newMicrosoft = ((ImageIcon) microsoft).getImage().getScaledInstance(125, 75, java.awt.Image.SCALE_SMOOTH);
        microsoft = new ImageIcon(newMicrosoft);

        //Creating Checklist
        dellXpsCheckBox = new JCheckBox("Dell XPS 15",dellXPS15);
        alienwareCheckBox = new JCheckBox("Alienware Aurora R15",Aleinware);
        microsoftCheckBox = new JCheckBox("Microsoft Surface Pro 9",microsoft);

        //Creating RadioButtons
        DellXpsRadioButton = new JRadioButton("Dell XPS 15",dellXPS15);
        alienwareRadioButton = new JRadioButton("Alienware Aurora R15",Aleinware);
        microsoftRadioButton = new JRadioButton("Microsoft Surface Pro 9",microsoft);

        //Price Button
        showPriceButton1 = new JButton("Calculate Price, CheckBox");
        JLabel space = new JLabel("                                                                                                                         ");
        showPriceButton2 = new JButton("Calculate Price, RadioButton");


        //Total Cost Panel and Text Field
        totalPriceTextfield1 = new JTextField("Price CheckBox: $");
        totalPriceTextfield1.setEditable(false);
        totalPriceTextfield1.setVisible(false);

        totalPriceTextfield2 = new JTextField("Price Radio Button: $");
        totalPriceTextfield2.setEditable(false);
        totalPriceTextfield2.setVisible(false);

        //Adding Componenets to Panel
        mainJPanel.add(teslaLogoButton);
        mainJPanel.add(button2Label);
        mainJPanel.add(mercedesButton);
        mainJPanel.add(buttonChecker);
        mainJPanel.add(dellXpsCheckBox);
        mainJPanel.add(alienwareCheckBox);
        mainJPanel.add(microsoftCheckBox);
        mainJPanel.add(showPriceButton1);
        mainJPanel.add(space);
        mainJPanel.add(DellXpsRadioButton);
        mainJPanel.add(alienwareRadioButton);
        mainJPanel.add(microsoftRadioButton);
        mainJPanel.add(showPriceButton2);
        mainJPanel.add(totalPriceTextfield1);
        mainJPanel.add(totalPriceTextfield2);
        mainJPanel.add(resetButton);

        JCheckBoxHandler handler = new JCheckBoxHandler();
        dellXpsCheckBox.addItemListener( handler );
        alienwareCheckBox.addItemListener( handler );
        microsoftCheckBox.addItemListener( handler );
        DellXpsRadioButton.addItemListener( handler );
        alienwareRadioButton.addItemListener( handler );
        microsoftRadioButton.addItemListener( handler );
        resetButton.addItemListener( handler );


        //Button 1 Action Listener
        teslaLogoButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e )
                    {
                        buttonChecker.setText("Button 1 has been selected");
                        buttonChecker.setSize(160, 20);
                    }
                }
        );
        //Button 2 Action Listener
        mercedesButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e )
                    {
                        buttonChecker.setText("Button 2 has been selected");
                        buttonChecker.setSize(160, 20);
                    }
                }
        );

        //Show Price Button Action Listener
        showPriceButton1.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e )
                    {
                        totalPriceTextfield1.setVisible(true);
                        totalPriceTextfield1.setBounds(350, 350, 160, 20);
                    }
                }
        );

        //Show Price Button Action Listener
        showPriceButton2.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e )
                    {
                        totalPriceTextfield2.setVisible(true);
                        totalPriceTextfield2.setBounds(650, 350, 160, 20);
                    }
                }
        );

        //Reset Selection Button Action Listener
        resetButton.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e )
                    {
                        DellXpsRadioButton.setEnabled(true);
                        alienwareRadioButton.setEnabled(true);
                        microsoftRadioButton.setEnabled(true);
                        totalPrice2 = 0;
                        totalPriceTextfield2.setText("Price: $");
                        totalPriceTextfield2.setSize(170, 20);
                    }
                }
        );

    }

    public static void main(String[] args) {
            Culminating();
    }

    //Action Listener for Checkbox
    private static class JCheckBoxHandler implements ItemListener {
        public void itemStateChanged( ItemEvent e) {
            if (e.getSource() == dellXpsCheckBox) {
                if (e.getStateChange() == ItemEvent.SELECTED);
                    totalPrice1 = totalPrice1 + 1199.99 + 15;
                totalPriceTextfield1.setText("Price: $" + (totalPrice1 * 1.13));
                totalPriceTextfield1.setSize(170, 20);
            }
            if (e.getSource() == alienwareCheckBox) {
                if (e.getStateChange() == ItemEvent.SELECTED);
                totalPrice1 = totalPrice1 + 1699.99 + 15;
                totalPriceTextfield1.setText("Price: $" + (totalPrice1 * 1.13));
                totalPriceTextfield1.setSize(170, 20);
            }
            if (e.getSource() == microsoftCheckBox) {
                if (e.getStateChange() == ItemEvent.SELECTED);
                totalPrice1 = totalPrice1 + 1399.99 + 15;
                totalPriceTextfield1.setText("Price: $" + totalPrice1 * 1.13);
                totalPriceTextfield1.setSize(170, 20);
            }
            if (e.getSource() == DellXpsRadioButton) {
                if (e.getStateChange() == ItemEvent.SELECTED);
                totalPrice2 = totalPrice2 + 1199.99 + 15;
                alienwareRadioButton.setEnabled(false);
                microsoftRadioButton.setEnabled(false);
                totalPriceTextfield2.setText("Price: $" + totalPrice2 * 1.13);
                totalPriceTextfield2.setSize(170, 20);
            }
            if (e.getSource() == alienwareRadioButton) {
                if (e.getStateChange() == ItemEvent.SELECTED);
                totalPrice2 = totalPrice2 + 1699.99 + 15;
                DellXpsRadioButton.setEnabled(false);
                microsoftRadioButton.setEnabled(false);
                totalPriceTextfield2.setText("Price: $" + totalPrice2 * 1.13);
                totalPriceTextfield2.setSize(170, 20);
            }
            if (e.getSource() == microsoftRadioButton) {
                if (e.getStateChange() == ItemEvent.SELECTED);
                totalPrice2 = totalPrice2 + 1399.99 + 15;
                DellXpsRadioButton.setEnabled(false);
                alienwareRadioButton.setEnabled(false);
                totalPriceTextfield2.setText("Price: $" + totalPrice2 * 1.13);
                totalPriceTextfield2.setSize(170, 20);
            }
        }

    }
}