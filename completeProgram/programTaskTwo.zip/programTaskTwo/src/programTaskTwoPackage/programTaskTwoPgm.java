package programTaskTwoPackage;
//***************************************************
//Name: Tesla Website
//Version: 0.1
//Target: Mr. Di Tomaso
//Author: Aayan Sheraz
//Purpose: To create a website for a client to easily customize their selection of a tesla car. It allows you to pick a model, exterior color, interior color, whether if you want Self Driving or not, a plate option, and what type of wheels you want. It has variety of options and displays the total price of your fully customized car with Hst and freight included. You can even restart your customization if you choose not to like an option.
//****************************************************

//Imports packages
import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.DecimalFormat;


public class programTaskTwoPgm {


    //Declares Variables
    public static double price, tax;
    public static JLabel exteriorColorLabel, wheelLabel, interiorColorLabel;
    public static JRadioButton restartSelectionRadioButton, cyberTruckRadioButton, modelYRadioButton, modelXRadioButton, redExteriorColorRadioButton, blackExteriorColorRadioButton, whiteExteriorColorRadioButton, silverExteriorColorRadioButton, blueExteriorColorRadioButton, allTerrainWheelsRadioButton, allSeasonWheelsRadioButton, blackInteriorColorRadioButton, whiteInteriorColorRadioButton, fullSelfDrivingRadioButton, noFullSelfDrivingRadioButton, plateOptionRadioButton, noPlateOptionRadioButton, checkoutRadioButton, teslaLogoRadioButton;
    public static double teslaTotalCost = 0, baseCarPrice;
    public static JTextField finalCostTextField;
    public static DecimalFormat decimalConversion = new DecimalFormat("1.11");
    public static String finalCostConverted;
    private static ButtonGroup baseCarSelectionGroup, exteriorColorGroup, interiorColorGroup, wheelGroup, fullSelfDivingGroup, plateGroup;

    public static void teslaCarWebsite() {
        //Creating the frame
        JFrame carSelectionFrame = new JFrame("Tesla Car Selection");
        JPanel carSelectionPanel = new JPanel();
        carSelectionFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        carSelectionFrame.add(carSelectionPanel);
        carSelectionFrame.setSize(1200, 1000);
        carSelectionFrame.setVisible(true);

        //Creating Logo

        Icon teslaLogoImage = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\programTaskTwo\\Images\\teslaLogo.png");
        Image newteslaLogoImage = ((ImageIcon) teslaLogoImage).getImage().getScaledInstance(80, 80, java.awt.Image.SCALE_SMOOTH);
        teslaLogoImage = new ImageIcon(newteslaLogoImage);
        teslaLogoRadioButton = new JRadioButton(teslaLogoImage);
        carSelectionPanel.add(teslaLogoRadioButton);



        //Images for Car Models
        Icon cyberTruckImage = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\programTaskTwo\\Images\\CyberTruck.PNG");
        Image newCyberTruckImage = ((ImageIcon) cyberTruckImage).getImage().getScaledInstance(80, 80, java.awt.Image.SCALE_SMOOTH);
        cyberTruckImage = new ImageIcon(newCyberTruckImage);

        Icon modelYImage = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\programTaskTwo\\Images\\ModelY.PNG");
        Image newModelYImage = ((ImageIcon) modelYImage).getImage().getScaledInstance(80, 80, java.awt.Image.SCALE_SMOOTH);
        modelYImage = new ImageIcon(newModelYImage);

        Icon modelXImage = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\programTaskTwo\\Images\\ModelX.PNG");
        Image newModelXImages = ((ImageIcon) modelXImage).getImage().getScaledInstance(80, 80, java.awt.Image.SCALE_SMOOTH);
        modelXImage = new ImageIcon(newModelXImages);

        //Car Model Radio Buttons
        JPanel carModelSelectionFrame = new JPanel();

        cyberTruckRadioButton = new JRadioButton("CyberTruck", cyberTruckImage);
        carModelSelectionFrame.add(cyberTruckRadioButton);
        modelYRadioButton = new JRadioButton("Model Y", modelYImage);
        carModelSelectionFrame.add(modelYRadioButton);
        modelXRadioButton = new JRadioButton("Model X", modelXImage);
        carModelSelectionFrame.add(modelXRadioButton);

        JLabel spaceLabel = new JLabel("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ");
        JLabel carModelLabel = new JLabel("Choose a Model");
        carSelectionPanel.add(spaceLabel);
        carSelectionPanel.add(carModelLabel);
        carSelectionPanel.add(carModelSelectionFrame);

        //Images for exterior color
        Icon redColor = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\programTaskTwo\\Images\\redImage.jpg");
        Image newRedColor = ((ImageIcon) redColor).getImage().getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
        redColor = new ImageIcon(newRedColor);

        Icon blackColor = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\programTaskTwo\\Images\\blackImage.png");
        Image newBlackColor = ((ImageIcon) blackColor).getImage().getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
        blackColor = new ImageIcon(newBlackColor);

        Icon whiteColor = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\programTaskTwo\\Images\\whiteImage.png");
        Image newWhiteColor = ((ImageIcon) whiteColor).getImage().getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
        whiteColor = new ImageIcon(newWhiteColor);

        Icon blueColor = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\programTaskTwo\\Images\\blueImage.png");
        Image newBlueColor = ((ImageIcon) blueColor).getImage().getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
        blueColor = new ImageIcon(newBlueColor);

        Icon silverColor = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\programTaskTwo\\Images\\silverImage.png");
        Image newSilverColor = ((ImageIcon) silverColor).getImage().getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
        silverColor = new ImageIcon(newSilverColor);

        JPanel exteriorSelectionFrame = new JPanel();

        //Radio Buttons for exterior colors
        redExteriorColorRadioButton = new JRadioButton("Ultra Red", redColor);
        exteriorSelectionFrame.add(redExteriorColorRadioButton);
        blackExteriorColorRadioButton = new JRadioButton("Solid Black", blackColor);
        exteriorSelectionFrame.add(blackExteriorColorRadioButton);
        whiteExteriorColorRadioButton = new JRadioButton("Pearl White", whiteColor);
        exteriorSelectionFrame.add(whiteExteriorColorRadioButton);
        blueExteriorColorRadioButton = new JRadioButton("Deep Blue Metallic", blueColor);
        exteriorSelectionFrame.add(blueExteriorColorRadioButton);
        silverExteriorColorRadioButton = new JRadioButton("Quicksilver", silverColor);
        exteriorSelectionFrame.add(silverExteriorColorRadioButton);

        exteriorColorLabel = new JLabel("Choose Exterior Color");
        carSelectionPanel.add(exteriorColorLabel);
        carSelectionPanel.add(exteriorSelectionFrame);

        //Images for wheels
        Icon allTerrainWheels = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\programTaskTwo\\Images\\allSeason.png");
        Image newAllTerrianWheels = ((ImageIcon) allTerrainWheels).getImage().getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
        allTerrainWheels = new ImageIcon(newAllTerrianWheels);

        Icon allSeasonWheels = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\programTaskTwo\\Images\\allSeason.png");
        Image newAllSeasonWheels = ((ImageIcon) allTerrainWheels).getImage().getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
        allSeasonWheels = new ImageIcon(newAllSeasonWheels);

        JPanel wheelsFrameSelection = new JPanel();

        //Wheels Radio Button
        allSeasonWheelsRadioButton = new JRadioButton("All Season Tires", allSeasonWheels);
        wheelsFrameSelection.add(allSeasonWheelsRadioButton);
        allTerrainWheelsRadioButton = new JRadioButton("All Terrain Tires", allTerrainWheels);
        wheelsFrameSelection.add(allTerrainWheelsRadioButton);

        wheelLabel = new JLabel("Choose your wheels");
        carSelectionPanel.add(wheelLabel);
        carSelectionPanel.add(wheelsFrameSelection);

        //AutoPilot Image
        Icon autoPilotImage = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\programTaskTwo\\Images\\autoPilot.png");
        Image newAutoPilotImage = ((ImageIcon) autoPilotImage).getImage().getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
        autoPilotImage = new ImageIcon(newAutoPilotImage);

        Icon noAutoPilot = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\programTaskTwo\\Images\\xNoAuto.png");
        Image newNoAutoPilot = ((ImageIcon) noAutoPilot).getImage().getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
        noAutoPilot = new ImageIcon(newNoAutoPilot);

        JPanel autoFrameSelection = new JPanel();

        //AutoPilot option
        fullSelfDrivingRadioButton = new JRadioButton("AutoPilot", autoPilotImage);
        autoFrameSelection.add(fullSelfDrivingRadioButton);
        noFullSelfDrivingRadioButton = new JRadioButton("No AutoPilot", noAutoPilot);
        autoFrameSelection.add(noFullSelfDrivingRadioButton);

        JLabel autoPilotLabel = new JLabel("Choose AutoPilot or No AutoPilot");
        carSelectionPanel.add(autoPilotLabel);
        carSelectionPanel.add(autoFrameSelection);

        //Images for Interior
        Icon blackColorInterior = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\programTaskTwo\\Images\\blackImage.png");
        Image newBlackColorInterior = ((ImageIcon) blackColorInterior).getImage().getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
        blackColorInterior = new ImageIcon(newBlackColorInterior);

        Icon whiteColorInterior = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\programTaskTwo\\Images\\whiteImage.png");
        Image newWhiteColorInterior = ((ImageIcon) whiteColorInterior).getImage().getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
        whiteColorInterior = new ImageIcon(newWhiteColorInterior);

        JPanel interiorSelectionFrame = new JPanel();

        //Interior Radio Button
        blackInteriorColorRadioButton = new JRadioButton("Black Interior", blackColorInterior);
        interiorSelectionFrame.add(blackInteriorColorRadioButton);
        whiteInteriorColorRadioButton = new JRadioButton("White Interior", whiteColorInterior);
        interiorSelectionFrame.add(whiteInteriorColorRadioButton);

        interiorColorLabel = new JLabel("Choose Interior Color");
        carSelectionPanel.add(interiorColorLabel);
        carSelectionPanel.add(interiorSelectionFrame);

        //Plate Image
        Icon plateOption = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\programTaskTwo\\Images\\plate.png");
        Image newplateOption = ((ImageIcon) plateOption).getImage().getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
        plateOption = new ImageIcon(newplateOption);

        Icon noPlateOption = new ImageIcon("C:\\Users\\sheraza093\\IdeaProjects\\programTaskTwo\\Images\\xNoAuto.png");
        Image newnoPlateOption = ((ImageIcon) noPlateOption).getImage().getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
        noPlateOption = new ImageIcon(newnoPlateOption);

        JPanel plateFrameSelection = new JPanel();

        //Plate option
        plateOptionRadioButton = new JRadioButton("Plate Option", plateOption);
        plateFrameSelection.add(plateOptionRadioButton);
        noPlateOptionRadioButton = new JRadioButton("No Plate Option", noPlateOption);
        plateFrameSelection.add(noPlateOptionRadioButton);

        JLabel plateOptionLabel = new JLabel("Choose Plate Option or No Plate option");
        carSelectionPanel.add(plateOptionLabel);
        carSelectionPanel.add(plateFrameSelection);

        //Price & Checkout
        JPanel newTextFrameSelection = new JPanel();

        finalCostTextField = new JTextField("PRICE", 45);
        newTextFrameSelection.add(finalCostTextField);
        finalCostTextField.setEditable(false);

        carSelectionPanel.add(newTextFrameSelection);

        JPanel checkoutFrameSelection = new JPanel();

        //Checkout Radio Button
        checkoutRadioButton = new JRadioButton("Checkout will Calculate - Price + HST + Freight");
        checkoutFrameSelection.add(checkoutRadioButton);

        restartSelectionRadioButton = new JRadioButton("Reset Purchase Option");
        checkoutFrameSelection.add(restartSelectionRadioButton);

        carSelectionPanel.add(checkoutFrameSelection);

        //Adding event listeners
        RadioButtonHandler handler = new RadioButtonHandler();
        cyberTruckRadioButton.addItemListener( handler );
        modelYRadioButton.addItemListener( handler );
        modelXRadioButton.addItemListener( handler );
        plateOptionRadioButton.addItemListener(handler);
        noPlateOptionRadioButton.addItemListener(handler);
        fullSelfDrivingRadioButton.addItemListener(handler);
        noFullSelfDrivingRadioButton.addItemListener(handler);
        redExteriorColorRadioButton.addItemListener(handler);
        blueExteriorColorRadioButton.addItemListener(handler);
        whiteExteriorColorRadioButton.addItemListener(handler);
        blackExteriorColorRadioButton.addItemListener(handler);
        silverExteriorColorRadioButton.addItemListener(handler);
        allTerrainWheelsRadioButton.addItemListener(handler);
        allSeasonWheelsRadioButton.addItemListener(handler);
        blackInteriorColorRadioButton.addItemListener(handler);
        whiteInteriorColorRadioButton.addItemListener(handler);
        checkoutRadioButton.addItemListener(handler);
        restartSelectionRadioButton.addItemListener(handler);
    }

    public static void main(String[] args)
    {
        teslaCarWebsite();
        final WindowAdapter windowAdapter = new WindowAdapter() {
            @Override
            public void windowActivated(WindowEvent e) {
                System.out.println("Window is closing");
            }
        };
    }

    private static class RadioButtonHandler implements ItemListener {
        public void itemStateChanged( ItemEvent e) {
            if (e.getSource() == cyberTruckRadioButton) {
                if (e.getStateChange() == ItemEvent.SELECTED)
                    baseCarPrice = 239990;
                modelXRadioButton.setEnabled(false);
                modelYRadioButton.setEnabled(false);
                teslaTotalCost = teslaTotalCost + 239990;
                finalCostTextField.setText("The Total Cost is: " + String.valueOf(teslaTotalCost));
            }
            else if (e.getSource() == modelYRadioButton) {
                if (e.getStateChange() == ItemEvent.SELECTED)
                    cyberTruckRadioButton.setEnabled(false);
                modelXRadioButton.setEnabled(false);
                baseCarPrice = 114990;
                teslaTotalCost = teslaTotalCost + baseCarPrice;
                finalCostTextField.setText("The Total cost is: " + String.valueOf(teslaTotalCost));
            }
            else if (e.getSource() == modelXRadioButton) {
                if (e.getStateChange() == ItemEvent.SELECTED)
                    cyberTruckRadioButton.setEnabled(false);
                modelYRadioButton.setEnabled(false);
                baseCarPrice = 116990;
                teslaTotalCost = teslaTotalCost + 116990;
                finalCostTextField.setText("The Total cost is: " + String.valueOf(teslaTotalCost));

            }

            //Exterior Color Fonts
            if (e.getSource() == whiteExteriorColorRadioButton ){
                if (e.getStateChange() == ItemEvent.SELECTED)
                    whiteExteriorColorRadioButton.setEnabled(true);
                blackExteriorColorRadioButton.setEnabled(false);
                blueExteriorColorRadioButton.setEnabled(false);
                redExteriorColorRadioButton.setEnabled(false);
                silverExteriorColorRadioButton.setEnabled(false);
                teslaTotalCost = teslaTotalCost + 1000;
                finalCostTextField.setText("The Total Cost is: " + String.valueOf(teslaTotalCost));
            }
            if (e.getSource() == blackExteriorColorRadioButton ){
                if (e.getStateChange() == ItemEvent.SELECTED)
                    blackExteriorColorRadioButton.setEnabled(true);
                whiteExteriorColorRadioButton.setEnabled(false);
                blueExteriorColorRadioButton.setEnabled(false);
                redExteriorColorRadioButton.setEnabled(false);
                silverExteriorColorRadioButton.setEnabled(false);
                teslaTotalCost = teslaTotalCost + 0;
                finalCostTextField.setText("The Total Cost is: " + String.valueOf(teslaTotalCost));
            }
            if (e.getSource() == blueExteriorColorRadioButton ){
                if (e.getStateChange() == ItemEvent.SELECTED)
                    blueExteriorColorRadioButton.setEnabled(true);
                blackExteriorColorRadioButton.setEnabled(false);
                whiteExteriorColorRadioButton.setEnabled(false);
                redExteriorColorRadioButton.setEnabled(false);
                silverExteriorColorRadioButton.setEnabled(false);
                teslaTotalCost = teslaTotalCost + 1000;
                finalCostTextField.setText("The Total Cost is: " + String.valueOf(teslaTotalCost));
            }
            if (e.getSource() == redExteriorColorRadioButton ){
                if (e.getStateChange() == ItemEvent.SELECTED)
                    redExteriorColorRadioButton.setEnabled(true);
                blackExteriorColorRadioButton.setEnabled(false);
                blueExteriorColorRadioButton.setEnabled(false);
                whiteExteriorColorRadioButton.setEnabled(false);
                silverExteriorColorRadioButton.setEnabled(false);
                teslaTotalCost = teslaTotalCost + 2000;
                finalCostTextField.setText("The Total Cost is: " + String.valueOf(teslaTotalCost));
            }
            if (e.getSource() == silverExteriorColorRadioButton ){
                if (e.getStateChange() == ItemEvent.SELECTED)
                    silverExteriorColorRadioButton.setEnabled(true);
                blackExteriorColorRadioButton.setEnabled(false);
                blueExteriorColorRadioButton.setEnabled(false);
                redExteriorColorRadioButton.setEnabled(false);
                whiteExteriorColorRadioButton.setEnabled(false);
                teslaTotalCost = teslaTotalCost + 2000;
                finalCostTextField.setText("The Total Cost is: " + String.valueOf(teslaTotalCost));
            }
            //Interior Fonts
            if (e.getSource() == blackInteriorColorRadioButton ){
            if (e.getStateChange() == ItemEvent.SELECTED)
                blackInteriorColorRadioButton.setEnabled(true);
            whiteInteriorColorRadioButton.setEnabled(false);
            teslaTotalCost = teslaTotalCost + 0;
            finalCostTextField.setText("The Total Cost is: " + String.valueOf(teslaTotalCost));
            }
            else if (e.getSource() == whiteInteriorColorRadioButton ){
            if (e.getStateChange() == ItemEvent.SELECTED)
                whiteInteriorColorRadioButton.setEnabled(true);
            blackInteriorColorRadioButton.setEnabled(false);
            teslaTotalCost = teslaTotalCost + 1000;
            finalCostTextField.setText("The Total Cost is: " + String.valueOf(teslaTotalCost));
            }

            //Wheels font
            if (e.getSource() == allTerrainWheelsRadioButton ){
                if (e.getStateChange() == ItemEvent.SELECTED)
                    allTerrainWheelsRadioButton.setEnabled(true);
                allSeasonWheelsRadioButton.setEnabled(false);
                teslaTotalCost = teslaTotalCost + 1200;
                finalCostTextField.setText("The Total Cost is: " + String.valueOf(teslaTotalCost));
            }
            if (e.getSource() == allSeasonWheelsRadioButton ) {
                if (e.getStateChange() == ItemEvent.SELECTED)
                    allSeasonWheelsRadioButton.setEnabled(true);
                allTerrainWheelsRadioButton.setEnabled(false);
                teslaTotalCost = teslaTotalCost + 0;
                finalCostTextField.setText("The Total Cost is: " + String.valueOf(teslaTotalCost));
            }
            //Plate Font
            if (e.getSource() == plateOptionRadioButton ) {
                if (e.getStateChange() == ItemEvent.SELECTED)
                    plateOptionRadioButton.setEnabled(true);
                noPlateOptionRadioButton.setEnabled(false);
                teslaTotalCost = teslaTotalCost + 2000;
                finalCostTextField.setText("The Total Cost is: " + String.valueOf(teslaTotalCost));
            }
            if (e.getSource() == noPlateOptionRadioButton ) {
                if (e.getStateChange() == ItemEvent.SELECTED)
                    noPlateOptionRadioButton.setEnabled(true);
                plateOptionRadioButton.setEnabled(false);
                teslaTotalCost = teslaTotalCost + 0;
                finalCostTextField.setText("The Total Cost is: " + String.valueOf(teslaTotalCost));
            }
            //AutoPilot Font
            if (e.getSource() == fullSelfDrivingRadioButton ) {
                if (e.getStateChange() == ItemEvent.SELECTED)
                    fullSelfDrivingRadioButton.setEnabled(true);
                noFullSelfDrivingRadioButton.setEnabled(false);
                teslaTotalCost = teslaTotalCost + 8000;
                finalCostTextField.setText("The Total Cost is: " + String.valueOf(teslaTotalCost));
            }
            if (e.getSource() == noFullSelfDrivingRadioButton ) {
                if (e.getStateChange() == ItemEvent.SELECTED)
                    noFullSelfDrivingRadioButton.setEnabled(true);
                fullSelfDrivingRadioButton.setEnabled(false);
                teslaTotalCost = teslaTotalCost + 0;
                finalCostTextField.setText("The Total Cost is: " + String.valueOf(teslaTotalCost));
            }
            //Checkout Button
            if (e.getSource() == checkoutRadioButton ) {
                if (e.getStateChange() == ItemEvent.SELECTED)
                    teslaTotalCost = (teslaTotalCost * 1.13)*1.025;

                //Decimal conversion
                String finalCostDecimalConversion = decimalConversion.format(teslaTotalCost);

                finalCostConverted = String.valueOf(teslaTotalCost);
                finalCostTextField.setText("The Final Cost with HST and Fright is: " + finalCostDecimalConversion);
            }
            //Restart Checkout
            if (e.getSource() == restartSelectionRadioButton ) {
                if (e.getStateChange() == ItemEvent.SELECTED)
                    cyberTruckRadioButton.setEnabled(true);
                modelYRadioButton.setEnabled(true);
                modelXRadioButton.setEnabled(true);
                fullSelfDrivingRadioButton.setEnabled(true);
                noFullSelfDrivingRadioButton.setEnabled(true);
                plateOptionRadioButton.setEnabled(true);
                noPlateOptionRadioButton.setEnabled(true);
                allTerrainWheelsRadioButton.setEnabled(true);
                allSeasonWheelsRadioButton.setEnabled(true);
                redExteriorColorRadioButton.setEnabled(true);
                blueExteriorColorRadioButton.setEnabled(true);
                whiteExteriorColorRadioButton.setEnabled(true);
                blackExteriorColorRadioButton.setEnabled(true);
                silverExteriorColorRadioButton.setEnabled(true);
                blackInteriorColorRadioButton.setEnabled(true);
                whiteInteriorColorRadioButton.setEnabled(true);
                teslaTotalCost = 0;
            }
            String finalCostDecimalConversion = decimalConversion.format(teslaTotalCost);

            finalCostConverted = String.valueOf(teslaTotalCost);
            finalCostTextField.setText("The Final Cost with HST and Fright is: " + finalCostDecimalConversion);
        }

    }
}