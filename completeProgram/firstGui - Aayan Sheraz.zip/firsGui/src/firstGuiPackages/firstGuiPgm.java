//************************************************************
//Name: firstGuiPgm
//Version: 0.1
//Author: Aayan Sheraz
//Purpose: To create a simple Gui and interface. This program allows you to type in a single text and click image & Button for it to change the property of the text field. Learning to create a button, text boxes, Images and varibles. Make them interactive to input from the keyboard and mouse.
//************************************************************



package firstGuiPackages;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class firstGuiPgm {
    /**
     * Declare objects
     */
    static JLabel label;
    static JTextField editableTxt, noneditableTxt;
    static JButton btnTxt;
    static JButton btnKhabib;

    //method to create GUI
    private static void guiApp() {

        //Create and set up the window.
        JFrame frame = new JFrame("Simple GUI");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //create and set up components
        JPanel panel = new JPanel();
        label = new JLabel("Selection Text");
        btnTxt = new JButton("Send text!");
        btnTxt.setActionCommand("Plain");

        //Icon moneyImg= new ImageIcon( "C:\\Users\\sheraza093\\IdeaProjects\\firsGui\\Images\\Money.jpg" );
        Icon Khabib = new ImageIcon ("C:\\Users\\sheraza093\\IdeaProjects\\firsGui\\Images\\Khabib.jpg");
        Image newKhabib2 = ((ImageIcon) Khabib).getImage().getScaledInstance(40,40, java.awt.Image.SCALE_SMOOTH);
        Khabib =new ImageIcon(newKhabib2);
        btnKhabib = new JButton(Khabib);
        //btnKhabib = new JButton("Diff text!");
        btnKhabib.setActionCommand("Fancy");

        //create a new ButtonHandler instance
        ButtonHandler onClick = new ButtonHandler();
        btnTxt.addActionListener(onClick);
        btnKhabib.addActionListener(onClick);

        editableTxt = new JTextField( "Programmers rock!", 20);
        noneditableTxt = new JTextField( "Uneditable text field", 15 );
        noneditableTxt.setEditable( false );

        panel.add(btnTxt);
        panel.add(btnKhabib);
        panel.add(label);
        panel.add(editableTxt);
        panel.add(noneditableTxt);

        frame.add(panel);
        frame.setSize(250,100);
        frame.setVisible(true);
    }

    //create custom event handler
    private static class ButtonHandler implements ActionListener {
        public void actionPerformed(ActionEvent e){
            //which button?
            String command = e.getActionCommand();
            //give message
            if(command.equals("Plain")){
                label.setText("You picked the plain button");
            } else {
                label.setText("You picked the Fancy Button!");
            }
        }
    }

    //main method to run the GUI
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                guiApp();
            }
        });
    }
}
